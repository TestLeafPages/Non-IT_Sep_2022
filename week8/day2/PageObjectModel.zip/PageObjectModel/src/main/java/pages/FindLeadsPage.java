package pages;

import baseclass.CommonClass;

public class FindLeadsPage extends CommonClass{

	//firstname
	//leadid
	//lnam
	
	//click first resulting name return viewLead
	
	
}
